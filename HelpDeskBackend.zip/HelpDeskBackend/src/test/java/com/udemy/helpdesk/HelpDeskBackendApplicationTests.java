package com.udemy.helpdesk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelpDeskBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
