package com.udemy.helpdesk.services;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.udemy.helpdesk.domain.Chamado;
import com.udemy.helpdesk.domain.Cliente;
import com.udemy.helpdesk.domain.Tecnico;
import com.udemy.helpdesk.domain.enums.Perfil;
import com.udemy.helpdesk.domain.enums.Prioridade;
import com.udemy.helpdesk.domain.enums.Status;
import com.udemy.helpdesk.repositories.ChamadoRepository;
import com.udemy.helpdesk.repositories.ClienteRepository;
import com.udemy.helpdesk.repositories.TecnicoRepository;

@Service
public class DBService {
	
	@Autowired
	private TecnicoRepository tecnicoRepository;
	@Autowired
	private ClienteRepository clienteRepository;
	@Autowired
	private ChamadoRepository chamadoRepository;
	
	@Autowired
	private BCryptPasswordEncoder encoder;
	
	public void instanciaDB() {
		
		Tecnico tec1 = new Tecnico(null, "Ana Castro", "23588922032", "anateste@mail.com", encoder.encode("123"));
		tec1.addPerfil(Perfil.ADMIN);
		Tecnico tec2 = new Tecnico(null, "Hanna Marin", "58555626030", "hmarin@mail.com", encoder.encode("123"));
		Tecnico tec3 = new Tecnico(null, "Spencer Hastings", "73593014084", "shastings@mail.com", encoder.encode("123"));
		Tecnico tec4 = new Tecnico(null, "Aria Montgomery", "83594321045", "amontgomery@mail.com", encoder.encode("123"));
		Tecnico tec5 = new Tecnico(null, "Emily Fields", "92104000033", "efields@mail.com", "123");
		Tecnico tec6 = new Tecnico(null, "Alison Dillarents", "04824998000", "adillarents@mail.com", encoder.encode("123"));
		Tecnico tec7 = new Tecnico(null, "Mona Wanderwall", "88257742066", "mwanderwall@mail.com",encoder.encode("123"));
	
		
		Cliente cli1 = new Cliente(null, "Jason Dillarents", "76783153096","jdillarents@mail.com" , encoder.encode("123"));
		Cliente cli2 = new Cliente(null, "Caleb Rivers", "91965493009","crivers@mail.com" , encoder.encode("123"));
		Cliente cli3 = new Cliente(null, "Toby Cavanaugh", "99826128082","tcavanaugh@mail.com" , encoder.encode("123"));
		Cliente cli4 = new Cliente(null, "Ezra Fitz", "63243318068","efitz@mail.com" ,encoder.encode("123"));
		Cliente cli5 = new Cliente(null, "Mike Montgomery", "85041796050","mmontgomery@mail.com" ,encoder.encode("123"));
		
	
		
		Chamado c1 = new Chamado(null, Prioridade.MEDIA, Status.ANDAMENTO, "Chamado 01", "Primeiro Chamado", tec1, cli1);
		Chamado c2 = new Chamado(null, Prioridade.ALTA, Status.ABERTO, "Chamado 2", "Teste chamado 2", tec1, cli2);
		Chamado c3 = new Chamado(null, Prioridade.BAIXA, Status.ENCERRADO, "Chamado 3", "Teste chamado 3", tec2, cli3);
		Chamado c4 = new Chamado(null, Prioridade.ALTA, Status.ABERTO, "Chamado 4", "Teste chamado 4", tec3, cli3);
		Chamado c5 = new Chamado(null, Prioridade.MEDIA, Status.ANDAMENTO, "Chamado 5", "Teste chamado 5", tec2, cli1);
		Chamado c6 = new Chamado(null, Prioridade.BAIXA, Status.ENCERRADO, "Chamado 7", "Teste chamado 6", tec1, cli5);
		
		tecnicoRepository.saveAll(Arrays.asList(tec1,tec2,tec3,tec4,tec5,tec6,tec7));
		clienteRepository.saveAll(Arrays.asList(cli1,cli2,cli3,cli4,cli5));
		chamadoRepository.saveAll(Arrays.asList(c1,c2,c3,c4,c5,c6));
	}

}
