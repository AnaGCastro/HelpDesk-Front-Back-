package com.udemy.helpdesk.config;

import org.springframework.security.config.annotation.web.builders.HttpSecurity;

public class WebSecurityConfigurerAdapter {

	public void configure(HttpSecurity http) {
		// TODO Auto-generated method stub
		
	}

}
